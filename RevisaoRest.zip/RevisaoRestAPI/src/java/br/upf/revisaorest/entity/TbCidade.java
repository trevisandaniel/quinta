/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.upf.revisaorest.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author danie
 */

@NamedNativeQueries({
    @NamedNativeQuery(name = "TbCidade.findbyPartDescricao",
            query = "select * from tb_cidade as cidade where tb_cidade.descricao ~* ?",
            resultClass = TbCidade.class)
})

@Entity
@Table(name = "tb_cidade")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TbCidade.findAll", query = "SELECT t FROM TbCidade t")
    , @NamedQuery(name = "TbCidade.findByIdCidade", query = "SELECT t FROM TbCidade t WHERE t.idCidade = :idCidade")
    , @NamedQuery(name = "TbCidade.findByDescricao", query = "SELECT t FROM TbCidade t WHERE t.descricao = :descricao")
    , @NamedQuery(name = "TbCidade.findByUf", query = "SELECT t FROM TbCidade t WHERE t.uf = :uf")})
public class TbCidade implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_cidade")
    private Integer idCidade;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 250)
    @Column(name = "descricao")
    private String descricao;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2)
    @Column(name = "uf")
    private String uf;

    public TbCidade() {
    }

    public TbCidade(Integer idCidade) {
        this.idCidade = idCidade;
    }

    public TbCidade(Integer idCidade, String descricao, String uf) {
        this.idCidade = idCidade;
        this.descricao = descricao;
        this.uf = uf;
    }

    public Integer getIdCidade() {
        return idCidade;
    }

    public void setIdCidade(Integer idCidade) {
        this.idCidade = idCidade;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCidade != null ? idCidade.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TbCidade)) {
            return false;
        }
        TbCidade other = (TbCidade) object;
        if ((this.idCidade == null && other.idCidade != null) || (this.idCidade != null && !this.idCidade.equals(other.idCidade))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "br.upf.revisaorest.entity.TbCidade[ idCidade=" + idCidade + " ]";
    }
    
}
