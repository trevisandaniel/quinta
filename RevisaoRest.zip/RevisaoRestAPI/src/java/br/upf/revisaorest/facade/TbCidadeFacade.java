/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.upf.revisaorest.facade;

import br.upf.revisaorest.entity.TbCidade;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author danie
 */
@Stateless
public class TbCidadeFacade extends AbstractFacade<TbCidade> {

    @PersistenceContext(unitName = "RevisaoRestAPIPU")
    private EntityManager em;
    
  

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public TbCidadeFacade() {
        super(TbCidade.class);
    }
    
    public List<TbCidade> findByPartDescricao(String partDescricao) {
        List<TbCidade> lista = new ArrayList<>();
        try {
            Query query = getEntityManager().createNamedQuery("TbCidade.findByPartDescricao");
            query.setParameter(1, partDescricao);
            lista = query.getResultList();
        } catch (Exception e) {
            System.err.println("Error: " + e);
        }
        return lista;
    }
    
}
