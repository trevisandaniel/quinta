/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.upf.revisaorest.rest;

import br.upf.revisaorest.entity.TbCidade;
import br.upf.revisaorest.facade.AbstractFacade;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author danie
 */
@Stateless
@Path("cidades")
public class CidadeService extends AbstractFacade<TbCidade>{
    
    @PersistenceContext(unitName = "RestCidadePU")
    private EntityManager em;
    
    @EJB
    private br.upf.revisaorest.facade.TbCidadeFacade ejbFacade;
    
    public CidadeService(){
        super(TbCidade.class);
    }
    
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
    @GET
    @Override
    @Path("/listALL")
    @Produces(MediaType.APPLICATION_JSON)
    public List<TbCidade> findAll(){
        return super.findAll();
    }
    
    @GET
    @Path("/findByPartDescricao/{partDescricao")
    @Produces({MediaType.APPLICATION_JSON})
    public List<TbCidade> findByPartDescricao(@PathParam("partDescricao") String descricao) {
        return ejbFacade.findByPartDescricao(descricao);
    }
    
}
